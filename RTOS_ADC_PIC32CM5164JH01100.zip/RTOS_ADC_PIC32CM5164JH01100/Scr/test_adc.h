#ifndef TEST_ADC_H      // Guards against multiple inclusion
#define TEST_ADC_H

#include <stdbool.h>
#include <stddef.h>
#include "pic32cm5164jh01100.h"

typedef uint32_t ADC_STATUS;

typedef void (*ADC_CALLBACK)(ADC_STATUS status, uintptr_t context);


typedef struct
{
    ADC_CALLBACK callback;

    uintptr_t context;

} ADC_CALLBACK_OBJ;



void ADC0_Initialize( void );

uint16_t ADC0_ConversionResultGet( void );

void ADC0_CallbackRegister( ADC_CALLBACK callback, uintptr_t context );

bool ADC0_ConversionStatusGet( void );

void ADC0_Enable(void);

void ADC0_ConversionStart(void);

uint16_t APP_ADC_ADCMeasurment(void);

#endif