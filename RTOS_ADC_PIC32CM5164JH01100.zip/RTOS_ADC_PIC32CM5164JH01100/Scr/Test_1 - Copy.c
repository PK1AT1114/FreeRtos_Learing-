#include "pic32cm5164jh01100.h"
#include "FreeRTOS.h"
#include "task.h"
#include <semphr.h> 
#include "test_adc.h"
#include "Clock_init.h"
#include "test_uart.h"
#include <stdio.h>
#include <string.h>

#define Set 0x01U
#define Clear 0x00U
#define LED_Pin 05U
#define VREF_ADC             (3.3f)
#define ADC_MAX_COUNT        (4095U)



float adcOutInVolts =0.0;
char adcResultatring[25]="ADC Result = ";
char adcString[6];
SemaphoreHandle_t testMutex;
//SemaphoreHandle_t CountSemaphore;
extern uint32_t SystemCoreClock;
static uint32_t u32_Systick_Value=0x00U;
static uint32_t u32_Systick_Flag_1sec=0x00U;
volatile uint16_t ADC_Data = 0x00;
volatile uint16_t sharedADCResult = 0x00;

TaskHandle_t Blink_Handle;

uint32_t CPUID;
uint8_t Hai_buff[4096] ={0};
void vBlinkTask(void *pvParameters) 
{
    // Initialize LED pin as output	
    while(1) 
		{
       // Toggle LED state
			
			if (xSemaphoreTake(testMutex,1U) == pdTRUE)
      {	
				adcOutInVolts = (float)sharedADCResult * VREF_ADC / ADC_MAX_COUNT;
				sprintf(adcString, "%.3f", adcOutInVolts);
				strcat(adcResultatring, adcString);								
			  xSemaphoreGive(testMutex);
				if(UART_TRANSFER(&adcResultatring,sizeof(adcResultatring)))
			  {
				    sharedADCResult = 0x0000U;
			  }
			}
      				
			vTaskDelay(pdMS_TO_TICKS(100));
			PORT_REGS->GROUP[2].PORT_OUTCLR |=(1<<0x05U);
			vTaskDelay(pdMS_TO_TICKS(1));
    }
}

void DataReadWrite(void *pvParameters) 
{
    BaseType_t xWasDelayed;
	  TickType_t xLastWakeTime;
    // Initialize LED pin as output
    while(1) 
		{
			   for(uint16_t loopVar=0x00; loopVar <=128 ;loopVar++)
			   {
			   	Hai_buff[loopVar] = (uint8_t)loopVar;
			   }
			    vTaskDelay(pdMS_TO_TICKS(1000));
			   for(uint16_t loopVar=0x00; loopVar <=128 ;loopVar++)
			   {
			   	Hai_buff[loopVar] = 0x00;
			   }
			   vTaskDelay(pdMS_TO_TICKS(1000));
    }
}


void ADC_Scan(void *pvParameters)
{
	  while(1) 
	  {
	    ADC_Data = APP_ADC_ADCMeasurment();
			vTaskDelay(pdMS_TO_TICKS(10));
			if (xSemaphoreTake(testMutex,1U) == pdTRUE)
      {
				if(sharedADCResult == 0x0000U)
				{
				    sharedADCResult = ADC_Data;
				    xSemaphoreGive(testMutex);
				}
				
				vTaskDelay(pdMS_TO_TICKS(500));
				PORT_REGS->GROUP[2].PORT_OUTSET |=(1<<0x05U);
				vTaskDelay(pdMS_TO_TICKS(1));
				
			}
		}
}


int main ( void )
{
	
	  PORT_REGS->GROUP[2].PORT_DIR |=(1<<0x05U);
	  PORT_REGS->GROUP[1].PORT_PINCFG[10] = 0x1U;
    PORT_REGS->GROUP[1].PORT_PINCFG[11] = 0x1U;

    PORT_REGS->GROUP[1].PORT_PMUX[5] = 0x33U;
	  UART_Initialize(115200);
	  ADC0_Initialize();
	  
	  ADC0_REGS->ADC_INPUTCTRL = (uint16_t) ADC_INPUTCTRL_MUXPOS_AIN11;
    while((ADC0_REGS->ADC_SYNCBUSY & ADC_SYNCBUSY_INPUTCTRL_Msk) == ADC_SYNCBUSY_INPUTCTRL_Msk)
    {
       
    }
    ADC0_REGS->ADC_SWTRIG |= ADC_SWTRIG_START_Msk|ADC_SWTRIG_FLUSH_Msk;
    while(0U != ADC0_REGS->ADC_SYNCBUSY)
    {
        
    }
    ADC0_ConversionResultGet();
		
	  testMutex = xSemaphoreCreateMutex();
//	  CountSemaphore = xSemaphoreCreateCounting(3,1);
	  if(testMutex != NULL)
		{
	      xTaskCreate(vBlinkTask, "BlinkTask", configMINIMAL_STACK_SIZE, NULL, 2, &Blink_Handle);
	      xTaskCreate(DataReadWrite, "DataReadWrite", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
			  xTaskCreate(ADC_Scan, "ADC_Scan", configMINIMAL_STACK_SIZE, NULL, 2, NULL);
	      vTaskStartScheduler();
		}
    while (1)
    {
        if(u32_Systick_Flag_1sec==0x01)
        {
            PORT_REGS->GROUP[2].PORT_OUTTGL |=(1<<LED_Pin);
            u32_Systick_Flag_1sec = Clear;
        }
    }
}
