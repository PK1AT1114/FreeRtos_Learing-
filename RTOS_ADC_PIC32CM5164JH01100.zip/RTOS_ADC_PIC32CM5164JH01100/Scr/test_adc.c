
#include "test_adc.h"

#define ADC0_LINEARITY_POS  (0U)
#define ADC0_LINEARITY_Msk   (0x7UL << ADC0_LINEARITY_POS)

#define ADC0_BIASCAL_POS  (3U)
#define ADC0_BIASCAL_Msk   (0x7UL << ADC0_BIASCAL_POS)

volatile static ADC_CALLBACK_OBJ ADC0_CallbackObject;

void ADC0_Initialize( void )
{

    /* Reset ADC */
    ADC0_REGS->ADC_CTRLA = (uint8_t)ADC_CTRLA_SWRST_Msk;

    while((ADC0_REGS->ADC_SYNCBUSY & ADC_SYNCBUSY_SWRST_Msk) == ADC_SYNCBUSY_SWRST_Msk)
    {
        
    }
    /* Write linearity calibration in BIASREFBUF and bias calibration in BIASCOMP */
    uint32_t calib_low_word = (uint32_t)(*(uint64_t*)OTP5_ADDR);
    ADC0_REGS->ADC_CALIB = (uint16_t)((ADC_CALIB_BIASREFBUF((calib_low_word & ADC0_LINEARITY_Msk) >> ADC0_LINEARITY_POS)) |
                                  (ADC_CALIB_BIASCOMP((calib_low_word & ADC0_BIASCAL_Msk) >> ADC0_BIASCAL_POS)));

    /* Prescaler */
    ADC0_REGS->ADC_CTRLB = (uint8_t)ADC_CTRLB_PRESCALER_DIV8;
    /* Sampling length */
    ADC0_REGS->ADC_SAMPCTRL = (uint8_t)ADC_SAMPCTRL_SAMPLEN(3UL);

    /* Reference */
    ADC0_REGS->ADC_REFCTRL = (uint8_t)ADC_REFCTRL_REFSEL_INTVCC2;

    /* Input pin */
    ADC0_REGS->ADC_INPUTCTRL = (uint16_t) ADC_INPUTCTRL_MUXPOS_SCALEDVDDCORE;

    /* Resolution & Operation Mode */
    ADC0_REGS->ADC_CTRLC = (uint16_t)(ADC_CTRLC_RESSEL_12BIT | ADC_CTRLC_WINMODE(0UL) | ADC_CTRLC_FREERUN_Msk);


    /* Clear all interrupt flags */
    ADC0_REGS->ADC_INTFLAG = (uint8_t)ADC_INTFLAG_Msk;
    while(0U != ADC0_REGS->ADC_SYNCBUSY)
    {
			
    }
        
}

uint16_t ADC0_ConversionResultGet( void )
{
    return (uint16_t)ADC0_REGS->ADC_RESULT;
}

void ADC0_CallbackRegister( ADC_CALLBACK callback, uintptr_t context )
{
    ADC0_CallbackObject.callback = callback;

    ADC0_CallbackObject.context = context;
}

/* Check whether result is ready */
bool ADC0_ConversionStatusGet( void )
{
    bool status;
    status =  (((ADC0_REGS->ADC_INTFLAG & ADC_INTFLAG_RESRDY_Msk) >> ADC_INTFLAG_RESRDY_Pos) != 0U);
    if (status == true)
    {
        ADC0_REGS->ADC_INTFLAG = (uint8_t)ADC_INTFLAG_RESRDY_Msk;
    }
    return status;
}

void __attribute__((used)) ADC0_InterruptHandler( void )
{
    ADC_STATUS status;
    status = ADC0_REGS->ADC_INTFLAG;
    /* Clear interrupt flag */

    if (ADC0_CallbackObject.callback != NULL)
    {
        uintptr_t context = ADC0_CallbackObject.context;
        ADC0_CallbackObject.callback(status, context);
    }
}

void ADC0_Enable(void)
{   
    ADC0_REGS->ADC_CTRLA = (uint8_t)ADC_CTRLA_ENABLE_Msk;
    
    while((ADC0_REGS->ADC_SYNCBUSY & ADC_SYNCBUSY_ENABLE_Msk) == ADC_SYNCBUSY_ENABLE_Msk)
    {
        /* Wait for Synchronization */;
    }
}

void ADC0_ConversionStart(void)
{
    /* Start ADC conversion */
    ADC0_REGS->ADC_SWTRIG |= ADC_SWTRIG_START_Msk;
    
    while ((ADC0_REGS->ADC_SYNCBUSY & ADC_SYNCBUSY_SWTRIG_Msk) == ADC_SYNCBUSY_SWTRIG_Msk)
    {
        /* Wait for Synchronization */
    }
}

uint16_t APP_ADC_ADCMeasurment(void)
{
    uint16_t adcResult = 0x00;
    adcResult = ADC0_REGS->ADC_RESULT;
    ADC0_Enable();
    ADC0_ConversionStart();
    while(!ADC0_ConversionStatusGet())
    {

    };
    adcResult = ADC0_REGS->ADC_RESULT;
    
    return adcResult;
}

