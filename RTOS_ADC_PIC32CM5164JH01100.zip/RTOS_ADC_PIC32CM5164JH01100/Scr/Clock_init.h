#ifndef CLOCK_INIT_H      // Guards against multiple inclusion
#define CLOCK_INIT_H

#include <stdbool.h>
#include <stddef.h>


void CLOCK_Initialize (void);

#endif