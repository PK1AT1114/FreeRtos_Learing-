#include "test_uart.h"

#define RX_DATA_PINOUT  0x03UL          //PAD3 is used as the UART RX data 
#define TX_DATA_PINOUT  0x01UL          //PAD2 is used as the UART TX data
#define FRAME_FORMAT    0x00UL			    //USART Farme Formate
#define USART_CLOCK     4000000U			  //4MHz
#define SAMPLE_RATE			0x00UL          //16 over sampling 

uint32_t tempValue = 0x00;

void UART_Initialize(uint32_t baudRate)
{	   
	  float temp;
    temp	= (65536U * (float)(1-((float)16*baudRate/USART_CLOCK))); 
	  
	  tempValue = (uint32_t)temp;
	
	  SERCOM4_REGS->USART_INT.SERCOM_CTRLA = SERCOM_USART_INT_CTRLA_MODE_USART_INT_CLK | SERCOM_USART_INT_CTRLA_RXPO(RX_DATA_PINOUT) | SERCOM_USART_INT_CTRLA_TXPO(TX_DATA_PINOUT) | SERCOM_USART_INT_CTRLA_DORD_Msk | SERCOM_USART_INT_CTRLA_IBON_Msk | SERCOM_USART_INT_CTRLA_FORM(FRAME_FORMAT) | SERCOM_USART_INT_CTRLA_SAMPR(SAMPLE_RATE) ;

    /* Configure Baud Rate */
    SERCOM4_REGS->USART_INT.SERCOM_BAUD = (uint16_t)SERCOM_USART_INT_BAUD_BAUD(tempValue);
    
	  SERCOM4_REGS->USART_INT.SERCOM_CTRLB = SERCOM_USART_INT_CTRLB_CHSIZE_8_BIT | SERCOM_USART_INT_CTRLB_SBMODE_1_BIT | SERCOM_USART_INT_CTRLB_RXEN_Msk | SERCOM_USART_INT_CTRLB_TXEN_Msk;

    /* Wait for sync */
    while((SERCOM4_REGS->USART_INT.SERCOM_SYNCBUSY) != 0U)
    {
        /* Do nothing */
    }


    /* Enable the UART after the configurations */
    SERCOM4_REGS->USART_INT.SERCOM_CTRLA |= SERCOM_USART_INT_CTRLA_ENABLE_Msk;

    /* Wait for sync */
//    while((SERCOM4_REGS->USART_INT.SERCOM_SYNCBUSY) != 0U)
//    {
//        /* Do nothing */
//    }
        
}

bool UART_TRANSFER( void *buffer, const size_t size )
{
    bool writeStatus      = false;
    uint8_t *pu8Data      = (uint8_t*)buffer;
    uint16_t *pu16Data    = (uint16_t*)buffer;
    uint32_t u32Index     = 0U;

    if(buffer != NULL)
    {
        /* Blocks while buffer is being transferred */
        while(u32Index < size)
        {
            /* Check if USART is ready for new data */
            while((SERCOM4_REGS->USART_INT.SERCOM_INTFLAG & (uint8_t)SERCOM_USART_INT_INTFLAG_DRE_Msk) == 0U)
            {
                /* Do nothing */
            }

            /* Write data to USART module */
            if (((SERCOM4_REGS->USART_INT.SERCOM_CTRLB & SERCOM_USART_INT_CTRLB_CHSIZE_Msk) >> SERCOM_USART_INT_CTRLB_CHSIZE_Pos) != 0x01U)
            {
                /* 8-bit mode */
                SERCOM4_REGS->USART_INT.SERCOM_DATA = pu8Data[u32Index];
            }
            else
            {
                /* 9-bit mode */
                SERCOM4_REGS->USART_INT.SERCOM_DATA = pu16Data[u32Index];
            }

            /* Increment index */
            u32Index++;
        }
        writeStatus = true;
    }

    return writeStatus;
}


