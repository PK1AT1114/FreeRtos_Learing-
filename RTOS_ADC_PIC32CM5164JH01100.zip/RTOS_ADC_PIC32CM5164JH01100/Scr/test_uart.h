#ifndef TEST_UART_H      // Guards against multiple inclusion
#define TEST_UART_H

#include <stdbool.h>
#include <stddef.h>
#include "pic32cm5164jh01100.h"

typedef uint32_t UART_STATUS;


void UART_Initialize(uint32_t baudRate);

bool UART_TRANSFER( void *buffer, const size_t size );

#endif