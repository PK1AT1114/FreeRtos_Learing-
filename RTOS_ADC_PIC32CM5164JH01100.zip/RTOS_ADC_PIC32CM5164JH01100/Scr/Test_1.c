#include "pic32cm5164jh01100.h"
#include "FreeRTOS.h"
#include "task.h"
#include <semphr.h>
#include "test_adc.h"
#include "Clock_init.h"
#include "test_uart.h"
#include <stdio.h>
#include <string.h>

#define LED_Pin 5U
#define VREF_ADC             (3.3f)
#define ADC_MAX_COUNT        (4095U)

float sharedAdcVoltage = 0.0f;  // Shared memory for ADC voltage
char adcString[30] = {0};
SemaphoreHandle_t xMutex;       // Mutex to protect access to the shared variable
extern uint32_t SystemCoreClock;
volatile uint16_t adcResult = 0; // ADC result


void vLEDTask(void *pvParameters)
{
    // LED Blink Task: Toggles the LED every 500ms
    while(1)
    {
        PORT_REGS->GROUP[2].PORT_OUTCLR |= (1 << LED_Pin); // Turn off LED
        vTaskDelay(pdMS_TO_TICKS(500)); // Delay for 500ms

        PORT_REGS->GROUP[2].PORT_OUTSET |= (1 << LED_Pin); // Turn on LED
        vTaskDelay(pdMS_TO_TICKS(50)); // Delay for 500ms
    }
}

void vADCTask(void *pvParameters)
{
    // ADC Measurement Task: Reads ADC and updates the shared memory
    while(1)
    {
        // Perform ADC measurement
        adcResult = APP_ADC_ADCMeasurment(); // Example ADC measurement function

        // Convert ADC result to voltage
        float adcVoltage = (float)adcResult * VREF_ADC / ADC_MAX_COUNT;

        // Lock the mutex before updating shared memory
        if (xSemaphoreTake(xMutex, pdMS_TO_TICKS(10)) == pdTRUE)
        {
            // Update the shared variable with the latest ADC voltage
            sharedAdcVoltage = adcVoltage;

            // Release the mutex after the update
            xSemaphoreGive(xMutex);
        }

        vTaskDelay(pdMS_TO_TICKS(500)); // Delay for 500ms before next ADC measurement
    }
}

void vUARTTask(void *pvParameters)
{
    // UART Task: Reads the shared memory and transmits via UART
    while(1)
    {
        // Lock the mutex before accessing the shared variable
        if (xSemaphoreTake(xMutex, pdMS_TO_TICKS(10)) == pdTRUE)
        {
            // Read the shared ADC voltage
            float localAdcVoltage = sharedAdcVoltage;

            // Release the mutex after reading the shared variable
            xSemaphoreGive(xMutex);

            // Prepare the string to send over UART
            sprintf(adcString, "ADC Voltage: %.3f V\r\n", localAdcVoltage);

            // Send the result over UART (Assuming UART_TRANSFER sends data)
            UART_TRANSFER(adcString, strlen(adcString));
        }

        vTaskDelay(pdMS_TO_TICKS(50)); // Delay for 500ms before the next transmission
    }
}

void System_hardware_init(void)
{
	 CLOCK_Initialize();
	 // Initialize hardware components
   PORT_REGS->GROUP[2].PORT_DIR |= (1 << LED_Pin); // Configure LED pin as output
	 
	 // UART Pin Initialization
	 PORT_REGS->GROUP[1].PORT_PINCFG[10] = 0x1U;
   PORT_REGS->GROUP[1].PORT_PINCFG[11] = 0x1U;
   PORT_REGS->GROUP[1].PORT_PMUX[5] = 0x33U;
}
int main(void)
{
	  System_hardware_init();
	   
    UART_Initialize(115200); // Initialize UART with baud rate 115200
    ADC0_Initialize();       // Initialize ADC

    // ADC Input Configuration
    ADC0_REGS->ADC_INPUTCTRL = (uint16_t)ADC_INPUTCTRL_MUXPOS_AIN11; // Select ADC channel
    while((ADC0_REGS->ADC_SYNCBUSY & ADC_SYNCBUSY_INPUTCTRL_Msk));   // Wait for ADC sync

    ADC0_REGS->ADC_SWTRIG |= ADC_SWTRIG_START_Msk | ADC_SWTRIG_FLUSH_Msk; // Start ADC
    while(ADC0_REGS->ADC_SYNCBUSY);   // Wait for synchronization
	
    ADC0_ConversionResultGet();       // Read initial conversion result

    // Create a mutex for protecting shared memory access
    xMutex = xSemaphoreCreateMutex();

    // Create tasks if the mutex was created successfully
    if (xMutex != NULL)
    {
        xTaskCreate(vLEDTask, "LEDTask", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
        xTaskCreate(vADCTask, "ADCTask", configMINIMAL_STACK_SIZE, NULL, 2, NULL);
        xTaskCreate(vUARTTask, "UARTTask", configMINIMAL_STACK_SIZE, NULL, 1, NULL);

        // Start the scheduler
        vTaskStartScheduler();
    }

    // Should never reach here
    while (1);
}
